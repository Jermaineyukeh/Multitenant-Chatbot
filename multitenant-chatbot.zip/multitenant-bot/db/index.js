const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "data.sqlite"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS clients (
  id TEXT PRIMARY KEY,
  business_name TEXT NOT NULL,
  tone TEXT DEFAULT 'friendly and professional',
  system_prompt TEXT,
  faq TEXT DEFAULT '[]',
  business_hours TEXT DEFAULT '',
  escalation_keywords TEXT DEFAULT 'refund,complaint,speak to human,agent',
  whatsapp_phone_number_id TEXT,
  whatsapp_access_token TEXT,
  ig_page_id TEXT,
  ig_page_access_token TEXT,
  active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS conversations (
  id TEXT PRIMARY KEY,
  client_id TEXT NOT NULL,
  channel TEXT NOT NULL,       -- 'whatsapp' | 'instagram'
  customer_id TEXT NOT NULL,   -- phone number or IG-scoped user id
  needs_human INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES clients(id)
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL,
  role TEXT NOT NULL,          -- 'user' | 'assistant'
  content TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (conversation_id) REFERENCES conversations(id)
);

CREATE INDEX IF NOT EXISTS idx_conv_client ON conversations(client_id);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id);
`);

module.exports = db;
