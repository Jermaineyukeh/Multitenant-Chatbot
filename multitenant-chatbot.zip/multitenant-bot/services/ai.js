const axios = require("axios");

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";

/**
 * Builds a system prompt for a specific client based on their configuration.
 */
function buildSystemPrompt(client) {
  let faqText = "";
  try {
    const faqs = JSON.parse(client.faq || "[]");
    if (faqs.length) {
      faqText = "\n\nFrequently asked questions and answers you should use:\n" +
        faqs.map((f, i) => `${i + 1}. Q: ${f.question}\n   A: ${f.answer}`).join("\n");
    }
  } catch (e) { /* ignore malformed faq json */ }

  return `You are a helpful customer service assistant for "${client.business_name}".
Tone: ${client.tone}.
${client.business_hours ? `Business hours: ${client.business_hours}.` : ""}
${client.system_prompt || ""}
${faqText}

Rules:
- Keep replies short and natural, suitable for a WhatsApp/Instagram chat (2-4 sentences max unless the customer asks for detail).
- If you don't know an answer, say so honestly and offer to connect them with a team member rather than guessing.
- Never invent prices, order statuses, or policies that were not given to you above.
- Do not mention that you are an AI unless directly asked.`;
}

/**
 * Calls Claude with the conversation history and returns the assistant's reply text.
 * history: [{role: 'user'|'assistant', content: string}, ...] oldest first
 */
async function getAIResponse(client, history) {
  const systemPrompt = buildSystemPrompt(client);

  const response = await axios.post(
    ANTHROPIC_URL,
    {
      model: process.env.CLAUDE_MODEL || "claude-sonnet-4-6",
      max_tokens: 400,
      system: systemPrompt,
      messages: history.map((m) => ({ role: m.role, content: m.content })),
    },
    {
      headers: {
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      timeout: 20000,
    }
  );

  const block = response.data.content.find((c) => c.type === "text");
  return block ? block.text.trim() : "Sorry, I couldn't process that — let me get a team member to help.";
}

/**
 * Simple keyword-based escalation check. Expand with your own logic as needed.
 */
function needsHumanHandoff(client, message) {
  const keywords = (client.escalation_keywords || "")
    .split(",")
    .map((k) => k.trim().toLowerCase())
    .filter(Boolean);
  const lower = message.toLowerCase();
  return keywords.some((k) => k && lower.includes(k));
}

module.exports = { getAIResponse, needsHumanHandoff, buildSystemPrompt };
