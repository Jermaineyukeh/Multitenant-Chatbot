const { nanoid } = require("nanoid");
const db = require("../db");

function getOrCreateConversation(clientId, channel, customerId) {
  let convo = db
    .prepare(
      "SELECT * FROM conversations WHERE client_id = ? AND channel = ? AND customer_id = ?"
    )
    .get(clientId, channel, customerId);

  if (!convo) {
    const id = nanoid();
    db.prepare(
      "INSERT INTO conversations (id, client_id, channel, customer_id) VALUES (?, ?, ?, ?)"
    ).run(id, clientId, channel, customerId);
    convo = db.prepare("SELECT * FROM conversations WHERE id = ?").get(id);
  }
  return convo;
}

function addMessage(conversationId, role, content) {
  const id = nanoid();
  db.prepare(
    "INSERT INTO messages (id, conversation_id, role, content) VALUES (?, ?, ?, ?)"
  ).run(id, conversationId, role, content);
}

function getHistory(conversationId, limit = 20) {
  const rows = db
    .prepare(
      "SELECT role, content FROM messages WHERE conversation_id = ? ORDER BY created_at ASC LIMIT ?"
    )
    .all(conversationId, limit);
  return rows;
}

function setNeedsHuman(conversationId, value) {
  db.prepare("UPDATE conversations SET needs_human = ? WHERE id = ?").run(
    value ? 1 : 0,
    conversationId
  );
}

module.exports = { getOrCreateConversation, addMessage, getHistory, setNeedsHuman };
