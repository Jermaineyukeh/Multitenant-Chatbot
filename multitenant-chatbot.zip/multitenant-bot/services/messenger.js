const axios = require("axios");

const GRAPH_VERSION = "v20.0";

async function sendWhatsAppMessage(client, toPhone, text) {
  const url = `https://graph.facebook.com/${GRAPH_VERSION}/${client.whatsapp_phone_number_id}/messages`;
  await axios.post(
    url,
    {
      messaging_product: "whatsapp",
      to: toPhone,
      type: "text",
      text: { body: text },
    },
    {
      headers: {
        Authorization: `Bearer ${client.whatsapp_access_token}`,
        "Content-Type": "application/json",
      },
    }
  );
}

async function sendInstagramMessage(client, recipientId, text) {
  const url = `https://graph.facebook.com/${GRAPH_VERSION}/${client.ig_page_id}/messages`;
  await axios.post(
    url,
    {
      recipient: { id: recipientId },
      message: { text },
    },
    {
      headers: {
        Authorization: `Bearer ${client.ig_page_access_token}`,
        "Content-Type": "application/json",
      },
    }
  );
}

module.exports = { sendWhatsAppMessage, sendInstagramMessage };
