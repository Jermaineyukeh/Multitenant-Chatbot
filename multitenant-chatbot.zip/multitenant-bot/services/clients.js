const { nanoid } = require("nanoid");
const db = require("../db");

function createClient(data) {
  const id = nanoid();
  db.prepare(
    `INSERT INTO clients
      (id, business_name, tone, system_prompt, faq, business_hours, escalation_keywords,
       whatsapp_phone_number_id, whatsapp_access_token, ig_page_id, ig_page_access_token)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    data.business_name,
    data.tone || "friendly and professional",
    data.system_prompt || "",
    JSON.stringify(data.faq || []),
    data.business_hours || "",
    data.escalation_keywords || "refund,complaint,speak to human,agent",
    data.whatsapp_phone_number_id || null,
    data.whatsapp_access_token || null,
    data.ig_page_id || null,
    data.ig_page_access_token || null
  );
  return getClientById(id);
}

function getClientById(id) {
  return db.prepare("SELECT * FROM clients WHERE id = ?").get(id);
}

function getClientByWhatsAppPhoneId(phoneNumberId) {
  return db
    .prepare("SELECT * FROM clients WHERE whatsapp_phone_number_id = ? AND active = 1")
    .get(phoneNumberId);
}

function getClientByIgPageId(pageId) {
  return db
    .prepare("SELECT * FROM clients WHERE ig_page_id = ? AND active = 1")
    .get(pageId);
}

function listClients() {
  return db.prepare("SELECT * FROM clients ORDER BY created_at DESC").all();
}

function updateClient(id, data) {
  const existing = getClientById(id);
  if (!existing) return null;
  const merged = { ...existing, ...data };
  db.prepare(
    `UPDATE clients SET business_name=?, tone=?, system_prompt=?, faq=?, business_hours=?,
     escalation_keywords=?, whatsapp_phone_number_id=?, whatsapp_access_token=?,
     ig_page_id=?, ig_page_access_token=?, active=? WHERE id=?`
  ).run(
    merged.business_name,
    merged.tone,
    merged.system_prompt,
    typeof merged.faq === "string" ? merged.faq : JSON.stringify(merged.faq || []),
    merged.business_hours,
    merged.escalation_keywords,
    merged.whatsapp_phone_number_id,
    merged.whatsapp_access_token,
    merged.ig_page_id,
    merged.ig_page_access_token,
    merged.active ? 1 : 0,
    id
  );
  return getClientById(id);
}

function deleteClient(id) {
  db.prepare("DELETE FROM clients WHERE id = ?").run(id);
}

module.exports = {
  createClient,
  getClientById,
  getClientByWhatsAppPhoneId,
  getClientByIgPageId,
  listClients,
  updateClient,
  deleteClient,
};
