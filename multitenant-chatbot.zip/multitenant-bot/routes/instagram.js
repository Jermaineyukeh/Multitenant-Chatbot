const express = require("express");
const router = express.Router();

const clientsSvc = require("../services/clients");
const convoSvc = require("../services/conversations");
const ai = require("../services/ai");
const { sendInstagramMessage } = require("../services/messenger");

router.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === process.env.IG_VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

router.post("/webhook", async (req, res) => {
  res.sendStatus(200);

  try {
    const entry = req.body.entry?.[0];
    const messaging = entry?.messaging?.[0];
    if (!messaging || !messaging.message?.text) return;

    const pageId = entry.id; // the connected Page/IG account receiving the message
    const senderId = messaging.sender.id;
    const text = messaging.message.text;

    const client = clientsSvc.getClientByIgPageId(pageId);
    if (!client) {
      console.warn(`No client configured for IG page ${pageId}`);
      return;
    }

    const convo = convoSvc.getOrCreateConversation(client.id, "instagram", senderId);
    convoSvc.addMessage(convo.id, "user", text);

    if (ai.needsHumanHandoff(client, text)) {
      convoSvc.setNeedsHuman(convo.id, true);
      await sendInstagramMessage(
        client,
        senderId,
        "Thanks for your message — a team member will follow up with you shortly."
      );
      return;
    }

    const history = convoSvc.getHistory(convo.id);
    const reply = await ai.getAIResponse(client, history);
    convoSvc.addMessage(convo.id, "assistant", reply);
    await sendInstagramMessage(client, senderId, reply);
  } catch (err) {
    console.error("Instagram webhook error:", err.response?.data || err.message);
  }
});

module.exports = router;
