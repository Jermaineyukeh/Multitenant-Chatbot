const express = require("express");
const router = express.Router();
const { requireAuth } = require("./auth");
const clientsSvc = require("../services/clients");
const db = require("../db");

router.use(requireAuth);

// List all clients (tenants)
router.get("/clients", (req, res) => {
  res.json(clientsSvc.listClients());
});

// Create a new client
router.post("/clients", (req, res) => {
  const created = clientsSvc.createClient(req.body);
  res.json(created);
});

// Get one client
router.get("/clients/:id", (req, res) => {
  const client = clientsSvc.getClientById(req.params.id);
  if (!client) return res.status(404).json({ error: "Not found" });
  res.json(client);
});

// Update a client's config (FAQs, tone, tokens, etc.)
router.put("/clients/:id", (req, res) => {
  const updated = clientsSvc.updateClient(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: "Not found" });
  res.json(updated);
});

// Delete a client
router.delete("/clients/:id", (req, res) => {
  clientsSvc.deleteClient(req.params.id);
  res.json({ ok: true });
});

// View conversations for a client
router.get("/clients/:id/conversations", (req, res) => {
  const convos = db
    .prepare("SELECT * FROM conversations WHERE client_id = ? ORDER BY created_at DESC")
    .all(req.params.id);
  res.json(convos);
});

// View messages for a conversation
router.get("/conversations/:id/messages", (req, res) => {
  const messages = db
    .prepare("SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC")
    .all(req.params.id);
  res.json(messages);
});

module.exports = router;
