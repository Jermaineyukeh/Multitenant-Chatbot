const express = require("express");
const router = express.Router();

const clientsSvc = require("../services/clients");
const convoSvc = require("../services/conversations");
const ai = require("../services/ai");
const { sendWhatsAppMessage } = require("../services/messenger");

// Meta verification handshake (GET)
router.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

// Incoming messages (POST)
router.post("/webhook", async (req, res) => {
  // Always ack immediately so Meta doesn't retry
  res.sendStatus(200);

  try {
    const entry = req.body.entry?.[0];
    const change = entry?.changes?.[0];
    const value = change?.value;
    const message = value?.messages?.[0];
    if (!message || message.type !== "text") return;

    const phoneNumberId = value.metadata?.phone_number_id;
    const fromPhone = message.from;
    const text = message.text.body;

    // Route to the correct tenant by their WhatsApp phone_number_id
    const client = clientsSvc.getClientByWhatsAppPhoneId(phoneNumberId);
    if (!client) {
      console.warn(`No client configured for phone_number_id ${phoneNumberId}`);
      return;
    }

    const convo = convoSvc.getOrCreateConversation(client.id, "whatsapp", fromPhone);
    convoSvc.addMessage(convo.id, "user", text);

    if (ai.needsHumanHandoff(client, text)) {
      convoSvc.setNeedsHuman(convo.id, true);
      await sendWhatsAppMessage(
        client,
        fromPhone,
        "Thanks for reaching out — I'm connecting you with a member of our team who will follow up shortly."
      );
      return;
    }

    const history = convoSvc.getHistory(convo.id);
    const reply = await ai.getAIResponse(client, history);
    convoSvc.addMessage(convo.id, "assistant", reply);
    await sendWhatsAppMessage(client, fromPhone, reply);
  } catch (err) {
    console.error("WhatsApp webhook error:", err.response?.data || err.message);
  }
});

module.exports = router;
